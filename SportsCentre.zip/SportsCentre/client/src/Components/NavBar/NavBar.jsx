import React, { useState } from 'react';
import styles from "./Style.NavBar.module.scss";
import { FaSearch, FaShoppingBag } from "react-icons/fa";
import { Link } from 'react-router-dom';
import Logo from './LogoNav.png';

import LoginModal from './LoginModal';
import SignUpModal from './SignUpModal';

const NavBar = () => {
  const [showLoginModal, setShowLoginModal] = useState(false);
  const toggleLoginModal = () => {
    setShowLoginModal(!showLoginModal);
  };

  const [showSignUpModal, setShowSignUpModal] = useState(false);
  const toggleSignUpModal = () => {
    setShowSignUpModal(!showSignUpModal);
  };

  const user = localStorage.getItem("token");

  const handleLogout = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("isAdmin");
    localStorage.removeItem("normalUser");
    localStorage.removeItem("CartPage");
    localStorage.removeItem("UpdateID");
    window.location = "/";
  };

  return (
    <div>
      <nav className={styles.navbar}>
        <div className={styles.left}>
          <img src={Logo} alt="Logo" className={styles.logo} />
          <ul className={styles["nav-links"]}>
            <li><a href="/">Home</a></li>
            <li><a href="/ProductPage">Products</a></li>
          </ul>
        </div>
        <div className={styles.searchBar}>
          <input type="text" placeholder="Search" />
          <FaSearch className={styles.searchIcon} />
        </div>
        <div className={styles.right}>
          <Link to="/CartPage" className={styles.shoppingBag}>
            <FaShoppingBag />
          </Link>
          {!user && <button className={`btn btn-outline-info my-2 my-sm-0 ${styles.mgl} ${styles.loginButton}`} onClick={toggleLoginModal}>Login</button>}
          {!user && <button className={`btn btn-outline-info my-2 my-sm-0 ${styles.mgl} ${styles.signUpButton}`} onClick={toggleSignUpModal}>Sign Up</button>}
          {user && <button className="btn btn-outline-danger my-2 my-sm-0" onClick={handleLogout}>Logout</button>}
        </div>
      </nav>
      <LoginModal show={showLoginModal} onHide={toggleLoginModal} />
      <SignUpModal show={showSignUpModal} onHide={toggleSignUpModal} />
    </div>
  );
};

export default NavBar;
