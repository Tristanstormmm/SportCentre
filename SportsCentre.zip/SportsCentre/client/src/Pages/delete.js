import React from "react";
import 'bootstrap/dist/css/bootstrap.min.css';

function DELETE() {
    return (
        <div>
        </div>
    )
}

export default DELETE;