import React from 'react';
import { Link } from 'react-router-dom';
import styles from './Style.Home.module.scss';
import Products from '../../Components/Products/Products';
import HomeImg from '../Home/HomeImg.jpg';


const Home = () => {
  return (
    <div className={styles.homePage}>
      <div className={styles.banner}>
      </div>

      <div className={styles.storeInfo}>
        <div className={styles.storeImage}>
          <img src={HomeImg} alt="Padel Store" />
        </div>
        <div className={styles.storeDescription}>
          <h2>About Our Store</h2>
          <p>
          Step into the world of SportCentre, where your athletic journey begins. Whether you're a seasoned pro or just starting out, our comprehensive range of sporting goods caters to all levels and interests. Discover cutting-edge equipment engineered for peak performance, from precision-crafted gear to innovative accessories. Browse through our curated selection of stylish athletic apparel, designed to blend comfort with functionality, keeping you at the top of your game. With SportCentre, excellence is within reach. Elevate your sporting experience and unleash your potential with the quality and expertise you deserve.
          </p>
          <Link to="/ProductPage" className={styles.viewProductsButton}>
            View Products
          </Link>
        </div>
      </div>
      <Products />
    </div>
  );
};

export default Home;
